

#include "foo.c"



long loop(long *a, long *b, long *c, long n) {
	long i, j;
	long x, y, z, sum;
	for (i = 0; i < n; ++i) {
		for (j = 0; j < n; ++j) {
			a[n*i+j] = b[j];
			c[i] += b[j];
			x = a[n*i+j];
			y = a[n*(i-foo())+j];
			z = a[n*i+(j-foo())];
			sum += x + y + z;
		}
	}
	return sum;
}
