long foo() {
	int i = 1;
	return i;
}
